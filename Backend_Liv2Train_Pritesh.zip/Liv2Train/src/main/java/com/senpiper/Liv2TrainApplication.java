package com.senpiper;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Liv2TrainApplication {

	public static void main(String[] args) {
		SpringApplication.run(Liv2TrainApplication.class, args);
	}

}
