package com.senpiper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Liv2TrainApplicationTests {

	@Test
	void contextLoads() {
	}

}
